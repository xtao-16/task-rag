import os
import glob
from typing import List
from langchain_community.document_loaders import TextLoader, PyMuPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document

from langchain_openai import OpenAIEmbeddings
from rag_mvp.config import settings


def _load_docs(data_dir: str) -> List[Document]:
    docs: List[Document] = []

    txt_files = glob.glob(os.path.join(data_dir, "**/*.txt"), recursive=True)
    md_files = glob.glob(os.path.join(data_dir, "**/*.md"), recursive=True)
    pdf_files = glob.glob(os.path.join(data_dir, "**/*.pdf"), recursive=True)

    for path in txt_files + md_files:
        loader = TextLoader(path, encoding="utf-8")
        docs.extend(loader.load())

    for path in pdf_files:
        loader = PyMuPDFLoader(path)
        docs.extend(loader.load())

    # 统一metadata
    for d in docs:
        d.metadata = d.metadata or {}
        d.metadata.setdefault("source", os.path.basename(d.metadata.get("source", "unknown")))
        d.metadata.setdefault("page", d.metadata.get("page", None))
        d.metadata["source"] = d.metadata.get("source") or "unknown"
    return docs


def _chunk(docs: List[Document]) -> List[Document]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=900,
        chunk_overlap=120,
        separators=["\n\n", "\n", "。", "！", "？", ".", " ", ""],
    )
    return splitter.split_documents(docs)


def build_index():
    os.makedirs(settings.INDEX_DIR, exist_ok=True)

    docs = _load_docs(settings.DATA_DIR)
    if not docs:
        raise RuntimeError(f"在 {settings.DATA_DIR} 未找到 txt/md/pdf 文档，请先放入文档再运行。")

    chunks = _chunk(docs)
    embeddings = OpenAIEmbeddings(model=settings.OPENAI_EMBED_MODEL)

    vectordb = FAISS.from_documents(chunks, embeddings)
    vectordb.save_local(settings.INDEX_DIR)
    return len(chunks)


def ensure_index():
    need_rebuild = (settings.REBUILD_INDEX == 1)
    index_exists = os.path.exists(settings.INDEX_DIR) and os.listdir(settings.INDEX_DIR)

    if need_rebuild or not index_exists:
        n = build_index()
        print(f"[RAG] 索引构建完成：chunks={n}，保存到 {settings.INDEX_DIR}")
    else:
        print(f"[RAG] 使用已有索引：{settings.INDEX_DIR}")
