from typing import List
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
from rag_mvp.config import settings

def load_vectordb():
    embeddings = OpenAIEmbeddings(model=settings.OPENAI_EMBED_MODEL)
    vectordb = FAISS.load_local(
        settings.INDEX_DIR,
        embeddings,
        allow_dangerous_deserialization=True
    )
    return vectordb

def retrieve(query: str, top_k: int = 6) -> List[Document]:
    vectordb = load_vectordb()
    retriever = vectordb.as_retriever(search_kwargs={"k": top_k})
    return retriever.get_relevant_documents(query)
