from fastapi import FastAPI, Body
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from rag_mvp.config import settings
from rag_mvp.ingestion import ensure_index
from rag_mvp.qa import answer_task_question

app = FastAPI(title="Task RAG MVP")

# 启动时确保索引存在
@app.on_event("startup")
def _startup():
    ensure_index()


@app.get("/", response_class=HTMLResponse)
def home():
    return """
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Task RAG MVP</title>
    <style>
      body{font-family: Arial, sans-serif; margin: 30px;}
      textarea{width:100%; height: 120px;}
      pre{background:#f5f5f5; padding:12px; white-space: pre-wrap;}
      button{padding:10px 14px; margin-top:10px;}
    </style>
  </head>
  <body>
    <h2>企业知识库 - 任务型问答（检索+长链推理）MVP</h2>
    <p>把企业文档放到 <code>data/</code> 目录后重启容器。</p>
    <textarea id="q" placeholder="输入问题，例如：报销需要哪些材料？按步骤输出并引用依据。"></textarea><br/>
    <button onclick="ask()">提问</button>
    <h3>答案</h3>
    <pre id="out"></pre>

    <script>
      async function ask(){
        const q = document.getElementById('q').value;
        const res = await fetch('/api/ask', {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body: JSON.stringify({query:q})
        });
        const data = await res.json();
        document.getElementById('out').textContent =
          JSON.stringify(data, null, 2);
      }
    </script>
  </body>
</html>
"""


class AskReq(BaseModel):
    query: str


@app.post("/api/ask")
def ask(req: AskReq = Body(...)):
    if not req.query.strip():
        return {"error": "query 不能为空"}
    return answer_task_question(req.query, top_k=settings.TOP_K)
