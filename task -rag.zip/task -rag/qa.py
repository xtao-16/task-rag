from typing import List, Dict, Any
from langchain_openai import ChatOpenAI

from rag_mvp.config import settings
from rag_mvp.retriever import retrieve
from rag_mvp.prompts import SYSTEM_PROMPT, user_prompt_template


def _format_context(docs) -> str:
    # 限制每段长度，防止提示词爆炸
    parts = []
    for i, d in enumerate(docs, start=1):
        src = d.metadata.get("source", "unknown")
        page = d.metadata.get("page", None)
        text = d.page_content
        parts.append(
            f"[材料{i}] source={src} page={page}\n{text[:1400]}"
        )
    return "\n\n".join(parts)


def answer_task_question(query: str, top_k: int = 6) -> Dict[str, Any]:
    docs = retrieve(query, top_k=top_k)
    context = _format_context(docs)

    llm = ChatOpenAI(model=settings.OPENAI_LLM_MODEL, temperature=0.2)

    resp = llm.invoke([
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_prompt_template(query, context)}
    ])

    sources = []
    for i, d in enumerate(docs, start=1):
        sources.append({
            "id": i,
            "source": d.metadata.get("source", "unknown"),
            "page": d.metadata.get("page", None)
        })

    return {
        "query": query,
        "answer": resp.content,
        "sources_used": sources
    }
