from pydantic import BaseSettings
import os

class Settings(BaseSettings):
    OPENAI_API_KEY: str = ""
    OPENAI_EMBED_MODEL: str = "text-embedding-3-small"
    OPENAI_LLM_MODEL: str = "gpt-4o-mini"
    TOP_K: int = 6
    REBUILD_INDEX: int = 0

    DATA_DIR: str = "data"
    INDEX_DIR: str = "faiss_index"

    class Config:
        env_file = ".env"
        extra = "ignore"

settings = Settings()
